using System.Threading.Tasks;
using Xunit;
using DisasterAlleviationFoundation_Web.Data;
using Microsoft.EntityFrameworkCore;
using DisasterAlleviationFoundation_Web.Models;
using System.Linq;

namespace DisasterAlleviationFoundation.Tests
{
    public class IncidentTests
    {
        [Fact]
        public async Task CanAddIncidentToInMemoryDb()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestIncidentsDb")
                .Options;

            using (var context = new ApplicationDbContext(options))
            {
                var inc = new Incident { Title = "Test", Location = "TestTown", Description = "Desc" };
                context.Incidents.Add(inc);
                await context.SaveChangesAsync();
            }

            using (var context = new ApplicationDbContext(options))
            {
                Assert.Equal(1, context.Incidents.Count());
            }
        }
    }
}
