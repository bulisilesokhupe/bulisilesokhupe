using System.Threading.Tasks;
using Xunit;
using Microsoft.EntityFrameworkCore;
using DisasterAlleviationFoundation_Web.Data;
using DisasterAlleviationFoundation_Web.Models;
using System.Linq;

namespace DisasterAlleviationFoundation.Tests
{
    public class IntegrationTests
    {
        [Fact]
        public async Task AddDonationAndRetrieve()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDonationsDb")
                .Options;

            using (var context = new ApplicationDbContext(options))
            {
                context.Donations.Add(new Donation { ResourceType = "Food", Quantity = 10, DonorName = "Tester" });
                await context.SaveChangesAsync();
            }

            using (var context = new ApplicationDbContext(options))
            {
                var d = context.Donations.FirstOrDefault();
                Assert.NotNull(d);
                Assert.Equal("Food", d.ResourceType);
            }
        }
    }
}
