using Microsoft.AspNetCore.Identity;

namespace DisasterAlleviationFoundation.Models
{
    public class ApplicationUser : IdentityUser
    {
        // Add extra fields here if required
    }
}
