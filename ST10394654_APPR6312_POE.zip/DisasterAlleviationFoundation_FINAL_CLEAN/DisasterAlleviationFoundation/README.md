# Disaster Alleviation Foundation

**Student:** Bulisile Douglas Sokhupe  
**Student ID:** ST10394654  
**Module:** APPR6312

## Overview
This is a submission-ready ASP.NET Core MVC application (NET 8) for the Disaster Alleviation Foundation. It includes Identity authentication (default Microsoft UI), LocalDB persistence, and a colorful modern UI theme.

## How to run
1. Open the solution in Visual Studio 2022 (17.8+) or run `dotnet restore` and `dotnet build`.
2. Ensure .NET 8 SDK is installed.
3. In Visual Studio, set the project as start-up, then **Build -> Rebuild Solution**.
4. In Package Manager Console (Tools -> NuGet Package Manager):
   - `dotnet ef migrations add InitialCreate`  (only if running first time)
   - `dotnet ef database update`
5. Run the application (F5). The app uses LocalDB, which is installed with Visual Studio.

## Features
- Home, Submit Claim, My Claims, Pending Claims pages
- User authentication (Login/Register) using Microsoft Identity UI
- Colorful gradient UI using Bootstrap & Bootstrap Icons
- LocalDB storage for persistence

## Notes for markers
- Identity pages use default Microsoft Identity UI (unchanged styling)
- Placeholder views are provided for claims pages; add model binding and persistence as necessary

---
