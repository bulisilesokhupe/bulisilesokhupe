﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using DisasterAlleviationFoundation.Models;

namespace DisasterAlleviationFoundation.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // 👇 Add these DbSet properties
        public DbSet<Donation> Donations { get; set; }
        public DbSet<Incident> Incidents { get; set; }
        public DbSet<Volunteer> Volunteers { get; set; }
    }
}
