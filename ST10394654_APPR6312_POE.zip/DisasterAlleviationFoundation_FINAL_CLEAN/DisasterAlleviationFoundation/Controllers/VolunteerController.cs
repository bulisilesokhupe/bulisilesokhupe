using Microsoft.AspNetCore.Mvc;
using DisasterAlleviationFoundation.Data;
using DisasterAlleviationFoundation.Models;
using System.Linq;

namespace DisasterAlleviationFoundation.Controllers
{
    public class VolunteerController : Controller
    {
        private readonly ApplicationDbContext _db;
        public VolunteerController(ApplicationDbContext db) { _db = db; }

        public IActionResult Index() => View(_db.Volunteers.ToList());

        public IActionResult Create() => View();

        [HttpPost]
        public IActionResult Create(Volunteer m)
        {
            if (ModelState.IsValid) { _db.Volunteers.Add(m); _db.SaveChanges(); return RedirectToAction("Index"); }
            return View(m);
        }
    }
}
