using Microsoft.AspNetCore.Mvc;

namespace DisasterAlleviationFoundation.Controllers
{
    public class ClaimController : Controller
    {
  
            public IActionResult Index()
            {
                return View();
            }

       

    public IActionResult SubmitClaim()
        {
            return View();
        }

        public IActionResult MyClaims()
        {
            return View();
        }

        public IActionResult PendingClaims()
        {
            return View();
        }
    }
}