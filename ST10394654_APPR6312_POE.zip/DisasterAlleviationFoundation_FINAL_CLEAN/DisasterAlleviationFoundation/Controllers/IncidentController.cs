using Microsoft.AspNetCore.Mvc;
using DisasterAlleviationFoundation.Data;
using DisasterAlleviationFoundation.Models;
using System.Linq;

namespace DisasterAlleviationFoundation.Controllers
{
    public class IncidentController : Controller
    {
        private readonly ApplicationDbContext _db;
        public IncidentController(ApplicationDbContext db) { _db = db; }

        public IActionResult Index() => View(_db.Incidents.ToList());

        public IActionResult Create() => View();

        [HttpPost]
        public IActionResult Create(Incident m)
        {
            if (ModelState.IsValid) { _db.Incidents.Add(m); _db.SaveChanges(); return RedirectToAction("Index"); }
            return View(m);
        }
    }
}
