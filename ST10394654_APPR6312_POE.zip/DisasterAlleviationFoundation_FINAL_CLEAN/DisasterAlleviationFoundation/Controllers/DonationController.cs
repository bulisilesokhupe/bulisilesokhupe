using Microsoft.AspNetCore.Mvc;
using DisasterAlleviationFoundation.Data;
using DisasterAlleviationFoundation.Models;
using System.Linq;

namespace DisasterAlleviationFoundation.Controllers
{
    public class DonationController : Controller
    {
        private readonly ApplicationDbContext _db;
        public DonationController(ApplicationDbContext db) { _db = db; }

        public IActionResult Index() => View(_db.Donations.ToList());

        public IActionResult Create() => View();

        public IActionResult Create(Donation m)
        {
            if (ModelState.IsValid)
            {
                _db.Donations.Add(m);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(m);
        }
    }
}
